from __future__ import annotations

import asyncio
import dataclasses
import json
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk, simpledialog
from tkinter.scrolledtext import ScrolledText

from .domain import Config
from . import __version__
from .engine import Manager
from .storage import atomic_json, data_dir, redact


class Bridge:
    def __init__(self, events, directory):
        self.events, self.directory = events, directory
        self.ready = threading.Event()
        self.loop = asyncio.new_event_loop()
        self.thread = threading.Thread(target=self._thread, daemon=True, name="browser-worker")
        self.thread.start()
        self.ready.wait(4)

    def _thread(self):
        asyncio.set_event_loop(self.loop)
        self.manager = Manager(self.directory, lambda event, data: self.events.put((event, data)))
        self.ready.set()
        self.loop.run_forever()

    def submit(self, name, *args):
        async def invoke():
            try:
                await getattr(self.manager, name)(*args)
            except asyncio.CancelledError:
                pass
            except Exception as exc:
                from .site import SiteProblem
                detail = str(exc) if isinstance(exc, SiteProblem) else (
                    f"{type(exc).__name__}: 操作できませんでした。ブラウザ・画面・起動環境を確認してください")
                self.manager.message("command_error", command=name, detail=detail)
                self.events.put(("error", {"message": redact(detail)}))
            finally:
                self.events.put(("busy_done", {"name": name}))
                if name == "shutdown":
                    self.events.put(("closed", {}))
        return asyncio.run_coroutine_threadsafe(invoke(), self.loop)


class App:
    def __init__(self, root: tk.Tk, demo: bool = False):
        self.root, self.demo = root, demo
        self.directory = data_dir()
        self.events = queue.Queue()
        self.bridge = None if demo else Bridge(self.events, self.directory)
        self.busy = set()
        self.config = self.load_settings()
        self.auth_ok = self.arena_ok = self.browser_open = self.active = self.closing = False
        self.connections = 0
        self.proxies = self.config.proxies
        root.title(f"SnayManager V2 ({__version__}) — 通常プレイヤー接続検証")
        root.geometry("1080x800")
        root.minsize(900, 690)
        ttk.Style().configure("Title.TLabel", font=("Yu Gothic UI", 17, "bold"))
        outer = ttk.Frame(root, padding=16)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="SnayManager V2", style="Title.TLabel").pack(anchor="w")
        ttk.Label(outer, text="タブを開いただけでは成功としません。接続制限を検出したら追加を停止します。").pack(anchor="w", pady=(3, 12))
        setup = ttk.LabelFrame(outer, text="1  ログインとアリーナ", padding=10)
        setup.pack(fill="x")
        self.channel = tk.StringVar(value=self.config.browser_channel)
        self.executable = tk.StringVar(value=self.config.executable_path)
        ttk.Label(setup, text="ブラウザ").grid(row=0, column=0, sticky="w")
        self.channel_in = ttk.Combobox(setup, values=["chrome", "chromium", "executable"], width=13,
                                      state="readonly", textvariable=self.channel)
        self.channel_in.grid(row=0, column=1, sticky="w", padx=6)
        self.path_button = ttk.Button(setup, text="実行ファイル選択", command=self.choose_browser)
        self.path_button.grid(row=0, column=2, padx=6)
        self.login_btn = ttk.Button(setup, text="① アカウントログイン", command=self.open_login)
        self.login_btn.grid(row=0, column=3, padx=6)
        self.verify_btn = ttk.Button(setup, text="② ログイン確認・保存", command=lambda: self.command("verify_login"))
        self.verify_btn.grid(row=0, column=4, padx=6)
        self.auth_text = tk.StringVar(value="未確認")
        ttk.Label(setup, textvariable=self.auth_text).grid(row=1, column=0, columnspan=4, sticky="w", pady=7)
        self.manual_btn = ttk.Button(setup, text="プロフィールを本人が目視確認", command=self.manual_auth)
        self.manual_btn.grid(row=1, column=4, sticky="e")
        self.manual_btn.state(["disabled"])
        self.arena_button = ttk.Button(setup, text="③ 現在のアリーナを取得", command=lambda: self.command("capture_arena"))
        self.arena_button.grid(row=2, column=0, columnspan=2, sticky="w")
        self.server, self.mode = tk.StringVar(value=self.config.server), tk.StringVar(value=self.config.mode)
        self.arena_text = tk.StringVar(value="ブラウザで選択してから取得してください")
        ttk.Label(setup, textvariable=self.arena_text).grid(row=2, column=2, columnspan=3, sticky="w", padx=8)
        ttk.Label(setup, textvariable=self.executable).grid(row=3, column=0, columnspan=5, sticky="w")
        options = ttk.LabelFrame(outer, text="2  検証条件", padding=10)
        options.pack(fill="x", pady=10)
        self.count = tk.StringVar(value=str(self.config.count))
        self.interval = tk.StringVar(value=str(self.config.interval_seconds))
        self.context_mode = tk.StringVar(value=self.config.context_mode)
        self.auto_respawn = tk.BooleanVar(value=self.config.auto_respawn)
        ttk.Label(options, text="生成数").grid(row=0, column=0)
        self.count_in = ttk.Spinbox(options, from_=1, to=20, width=5, textvariable=self.count)
        self.count_in.grid(row=0, column=1, padx=6)
        self.presets = []
        for col, count in enumerate((1, 2, 5, 10, 20), 2):
            button = ttk.Button(options, text=str(count), width=3,
                               command=lambda value=count: self.count.set(str(value)))
            button.grid(row=0, column=col, padx=2)
            self.presets.append(button)
        ttk.Label(options, text="起動間隔（秒）").grid(row=0, column=7, padx=(14, 4))
        self.interval_in = ttk.Spinbox(options, from_=1, to=60, width=5, textvariable=self.interval)
        self.interval_in.grid(row=0, column=8)
        self.mode_in = ttk.Combobox(options, textvariable=self.context_mode, values=["shared", "isolated"],
                                   state="readonly", width=12)
        self.mode_in.grid(row=0, column=9, padx=12)
        self.proxy_button = ttk.Button(options, text="ネットワーク設定（任意）", command=self.proxy_dialog)
        self.proxy_button.grid(row=0, column=10, sticky="e")
        ttk.Label(options, text="shared＝同じコンテキストのタブ ／ isolated＝同じ認証を復元した独立コンテキスト").grid(
            row=1, column=0, columnspan=11, sticky="w", pady=7)
        ttk.Checkbutton(options, variable=self.auto_respawn, text="死亡時に自動リスポーン（最大3回）").grid(
            row=2, column=0, columnspan=7, sticky="w")
        self.allowed = tk.BooleanVar(value=False)
        ttk.Checkbutton(options, variable=self.allowed,
                        text="このアリーナ・人数・接続経路で検証の許可があることを確認しました",
                        command=self.controls).grid(row=3, column=0, columnspan=11, sticky="w")
        buttons = ttk.Frame(outer)
        buttons.pack(fill="x")
        self.start_btn = ttk.Button(buttons, text="START  段階検証", command=self.start)
        self.start_btn.pack(side="left")
        self.stop_btn = ttk.Button(buttons, text="STOP ALL", command=lambda: self.command("stop_all"))
        self.stop_btn.pack(side="left", padx=10)
        self.report_btn = ttk.Button(buttons, text="診断レポート保存", command=lambda: self.command("export_report"))
        self.report_btn.pack(side="left", padx=5)
        ttk.Button(buttons, text="過去の結果を比較", command=lambda: self.command("compare_history")).pack(side="left", padx=5)
        ttk.Button(buttons, text="ログフォルダー", command=self.open_logs).pack(side="right")
        self.update_btn = ttk.Button(buttons, text="更新ZIP（手動）", command=self.update_from_zip)
        self.update_btn.pack(side="right", padx=8)
        self.autoupdate_btn = ttk.Button(buttons, text="自動更新の設定", command=self.configure_auto_update)
        self.autoupdate_btn.pack(side="right", padx=8)
        self.metrics = tk.StringVar(value="起動タブ 0  |  スポーン確認 0  |  未確認 0  |  失敗・切断 0")
        ttk.Label(outer, textvariable=self.metrics, font=("Yu Gothic UI", 11, "bold")).pack(anchor="w", pady=10)
        self.reason = tk.StringVar()
        ttk.Label(outer, textvariable=self.reason, wraplength=990).pack(anchor="w")
        columns = ("id", "status", "network", "context", "code", "detail")
        table_frame = ttk.Frame(outer)
        table_frame.pack(fill="both", expand=True, pady=(4, 7))
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=9)
        for col, label, width in zip(columns, ["番号", "状態", "経路", "方式", "エラーコード", "詳細"],
                                    [45, 150, 80, 75, 190, 360]):
            self.tree.heading(col, text=label)
            self.tree.column(col, width=width, stretch=col == "detail")
        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.log = ScrolledText(outer, height=8, font=("Yu Gothic UI", 9), state="disabled")
        self.log.pack(fill="x")
        self.log_line("初回は1体→2体。ログインは専用Chromeで行います。")
        if demo:
            self.log_line("GUIデモのみ。実サーバー未接続。成功数は0のままです。")
        self.controls()
        root.protocol("WM_DELETE_WINDOW", self.close)
        root.after(100, self.poll)

    def load_settings(self):
        path = self.directory / "settings.json"
        if not path.exists():
            root = Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parents[1]
            path = root / "settings.json"
        try:
            if path.exists():
                return Config.from_dict(json.loads(path.read_text(encoding="utf-8")))
        except Exception:
            pass
        return Config()

    def current_config(self):
        return dataclasses.replace(self.config, count=int(self.count.get()),
            interval_seconds=float(self.interval.get()), context_mode=self.context_mode.get(),
            browser_channel=self.channel.get(), executable_path=self.executable.get(),
            server=self.server.get(), mode=self.mode.get(), proxies=self.proxies,
            auto_respawn=self.auto_respawn.get())

    def command(self, name, *args):
        if self.demo:
            self.log_line("デモ：ブラウザ操作は行いません")
            return
        if self.closing and name != "shutdown":
            return
        if self.busy and name not in {"stop_all", "shutdown"}:
            return
        self.busy.add(name)
        self.controls()
        self.bridge.submit(name, *args)

    def open_login(self):
        try:
            config = self.current_config()
            config.validate()
            self.command("open_login", config)
        except (TypeError, ValueError) as exc:
            messagebox.showerror("入力確認", str(exc), parent=self.root)

    def choose_browser(self):
        path = filedialog.askopenfilename(title="Chrome / Chromiumの実行ファイル")
        if path:
            self.executable.set(path)
            self.channel.set("executable")

    def manual_auth(self):
        if messagebox.askyesno("本人確認", "専用ブラウザのプロフィールに、自分のアカウントが表示されていますか？\n"
                               "自動確認できなかったため、本人による目視確認として記録します。", parent=self.root):
            self.command("confirm_profile")

    def start(self):
        try:
            config = self.current_config()
            config.validate(require_server=True)
            if not self.allowed.get():
                raise ValueError("検証の許可を確認してください")
            text = f"{config.mode} / {config.server}\n最大{config.count}体を順番に検証します。\n\n"
            text += "途中で既存プレイヤーが切断された場合も追加を停止します。\n開始しますか？"
            if not messagebox.askyesno("対象確認", text, parent=self.root):
                return
            self.config = config
            atomic_json(self.directory / "settings.json", config.to_dict())
            self.command("start", config, self.allowed.get())
        except (TypeError, ValueError) as exc:
            messagebox.showerror("入力確認", str(exc), parent=self.root)

    def proxy_dialog(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("許可済みネットワークの固定割当")
        dialog.geometry("760x440")
        ttk.Label(dialog, text="0行＝直接接続。使用する場合は生成数と同じ行数をJSON配列で指定。\n"
                  "経路は固定です。拒否後の自動ローテーションや再接続はしません。\n"
                  "認証の値は書かず、PC上の環境変数名だけを指定してください。").pack(anchor="w", padx=12, pady=12)
        editor = ScrolledText(dialog, font=("Consolas", 10))
        editor.pack(fill="both", expand=True, padx=12)
        editor.insert("1.0", json.dumps([dataclasses.asdict(p) for p in self.proxies], ensure_ascii=False, indent=2))
        ttk.Label(dialog, text='例：{"server":"http://127.0.0.1:8080","label":"network-a",'
                              '"username_env":"SNAY_PROXY_USER","password_env":"SNAY_PROXY_PASS"}').pack(
                                  anchor="w", padx=12, pady=7)
        def save():
            from .domain import Proxy
            try:
                data = json.loads(editor.get("1.0", "end"))
                if not isinstance(data, list):
                    raise ValueError("JSON配列にしてください")
                self.proxies = tuple(Proxy.from_dict(p) for p in data)
                if self.proxies:
                    self.context_mode.set("isolated")
                dialog.destroy()
            except (ValueError, TypeError) as exc:
                messagebox.showerror("設定確認", str(exc), parent=dialog)
        ttk.Button(dialog, text="適用", command=save).pack(pady=8)

    def configure_auto_update(self):
        """Configure a trusted GitHub releases repository for the installed launcher."""
        import re
        path = self.directory / "update-config.json"
        try:
            config = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}
        except (ValueError, OSError):
            config = {}
        current = config.get("github_repo", "")
        info = ("自動更新を配布するGitHubリポジトリを指定してください。\n"
                "例: account/SnayManagerV2\n\n"
                "未設定の間は自動更新できません。公開される更新ZIPにはPythonコードが含まれるため、\n"
                "ご自身が信頼する配布元だけを登録してください。")
        value = simpledialog.askstring("自動更新の配布先", info, initialvalue=current, parent=self.root)
        if value is None:
            return
        value = value.strip()
        if value and not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", value):
            messagebox.showerror("設定エラー", "owner/repository の形式で入力してください。", parent=self.root)
            return
        atomic_json(path, {"github_repo": value, "enabled": bool(value)})
        if value:
            messagebox.showinfo("保存完了", "次回SnayManager起動時から更新を自動確認します。\n配布先: " + value, parent=self.root)
        else:
            messagebox.showinfo("設定完了", "自動更新を無効にしました。", parent=self.root)

    def update_from_zip(self):
        """Hand over a trusted ZIP to a separate updater after closing the app."""
        if getattr(sys, "frozen", False):
            messagebox.showinfo("アップデート", "EXE版ではこの更新方法はまだ利用できません。ソース起動版でお試しください。", parent=self.root)
            return
        if self.busy or self.active or self.connections:
            messagebox.showinfo("アップデート", "先に STOP ALL を押し、すべてのタブが終了してから更新してください。", parent=self.root)
            return
        archive = filedialog.askopenfilename(
            title="SnayManagerの更新ZIPを選択（展開不要）",
            filetypes=[("ZIPファイル", "*.zip")], parent=self.root)
        if not archive:
            return
        try:
            from updater import inspect_zip, UpdateError
            count = len(inspect_zip(Path(archive)))
        except Exception as exc:
            messagebox.showerror("更新ZIPを確認できません", str(exc), parent=self.root)
            return
        yes = messagebox.askyesno(
            "アップデート確認",
            f"現在の版: {__version__}\n選択したZIP: {Path(archive).name}\n"
            f"更新対象: {count}ファイル\n\nログイン情報と個人設定は保持します。"
            "\nSnayManagerを一度終了し、更新後に再起動します。"
            "\n※信頼できるSnayManagerのZIPだけを選んでください。\n続けますか？",
            parent=self.root)
        if not yes:
            return
        root = Path(__file__).resolve().parents[1]
        updater = root / "updater.py"
        if not updater.is_file():
            messagebox.showerror("更新できません", "updater.py が見つかりません", parent=self.root)
            return
        command = [sys.executable, str(updater), "--archive", str(Path(archive).resolve()),
                   "--target", str(root), "--wait-pid", str(os.getpid()), "--restart"]
        try:
            flags = subprocess.CREATE_NEW_CONSOLE if os.name == "nt" else 0
            subprocess.Popen(command, cwd=str(root), creationflags=flags)
        except OSError as exc:
            messagebox.showerror("更新開始エラー", str(exc), parent=self.root)
            return
        self.log_line("更新プログラムに引き継ぎました。終了後、自動で再起動します。")
        self.close()

    def open_logs(self):
        path = self.directory / "logs"
        path.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            os.startfile(path)
        else:
            subprocess.Popen(["xdg-open", str(path)])

    def log_line(self, value):
        self.log.configure(state="normal")
        self.log.insert("end", value + "\n")
        if int(self.log.index("end-1c").split(".")[0]) > 900:
            self.log.delete("1.0", "200.0")
        self.log.see("end")
        self.log.configure(state="disabled")

    def controls(self):
        locked = bool(self.busy or self.active or self.connections or self.closing)
        def set_enabled(button, yes):
            button.state(["!disabled"] if yes else ["disabled"])
        set_enabled(self.login_btn, not locked)
        set_enabled(self.verify_btn, self.browser_open and not locked)
        set_enabled(self.arena_button, self.auth_ok and not locked)
        set_enabled(self.start_btn, self.auth_ok and self.arena_ok and self.allowed.get() and not locked)
        set_enabled(self.stop_btn, bool(self.active or self.connections or self.busy) and not self.closing)
        set_enabled(self.proxy_button, not locked)
        set_enabled(self.report_btn, not self.closing)
        set_enabled(self.update_btn, not locked)
        set_enabled(self.autoupdate_btn, not locked)
        for control in (self.count_in, self.interval_in, self.path_button, *self.presets):
            set_enabled(control, not locked)
        self.channel_in.configure(state="disabled" if locked else "readonly")
        self.mode_in.configure(state="disabled" if locked else "readonly")

    def poll(self):
        for _ in range(120):
            try:
                event, data = self.events.get_nowait()
            except queue.Empty:
                break
            if event == "log":
                self.log_line(data["time"][11:19] + "  " + data["event"] + "  " +
                              json.dumps({k: v for k, v in data.items() if k not in {"time", "event"}}, ensure_ascii=False))
            elif event == "error":
                self.log_line("エラー：" + data["message"])
            elif event == "busy_done":
                self.busy.discard(data["name"])
                if data["name"] == "open_login":
                    self.browser_open = bool(self.bridge.manager.login_site)
                self.controls()
            elif event == "auth":
                self.auth_text.set("ログイン状態：" + data["state"])
                self.auth_ok = self.bridge.manager.authenticated
                self.manual_btn.state(["!disabled"] if data["manual_allowed"] else ["disabled"])
            elif event == "arena":
                self.server.set(data["server"])
                self.mode.set(data["mode"])
                self.arena_text.set(data["mode"] + " / " + data["server"])
                self.arena_ok = True
            elif event == "login_closed":
                self.browser_open = False
                self.log_line(data["reason"])
                self.controls()
            elif event == "players":
                self.connections, self.active = data["tabs_open"], data["active"]
                self.metrics.set(f'起動タブ {data["tabs_open"]}  |  スポーン確認 {data["spawn_verified_now"]}'
                                 f'  |  死亡 {data.get("dead", 0)}'
                                 f'  |  未確認 {data["unverified"]}  |  失敗・切断 {data["failed"]}'
                                 f'  |  同時確認の最大 {data["peak"]}')
                self.reason.set("追加停止理由：" + data["halt_reason"] if data["halt_reason"] else "")
                for row in data["rows"]:
                    key = str(row["index"])
                    values = (row["index"], row["state"], row["network"], row["context_mode"], row["code"], row["detail"])
                    if self.tree.exists(key):
                        self.tree.item(key, values=values)
                    else:
                        self.tree.insert("", "end", iid=key, values=values)
                keep = {str(row["index"]) for row in data["rows"]}
                for key in self.tree.get_children():
                    if key not in keep:
                        self.tree.delete(key)
                self.controls()
            elif event == "closed":
                self.bridge.loop.call_soon_threadsafe(self.bridge.loop.stop)
                self.root.destroy()
                return
        self.root.after(100, self.poll)

    def close(self):
        if self.closing:
            return
        self.closing = True
        self.controls()
        if self.demo:
            self.root.destroy()
        else:
            self.command("shutdown")


def main():
    root = tk.Tk()
    App(root, "--demo" in sys.argv)
    root.mainloop()
