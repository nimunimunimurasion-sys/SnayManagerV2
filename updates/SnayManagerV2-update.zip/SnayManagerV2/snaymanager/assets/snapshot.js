() => {
  const one = s => document.querySelector(s);
  const text = el => String(el?.innerText || "").replace(/\s+/g, " ").trim();
  const visible = el => {
    if (!el?.isConnected || !el.getClientRects().length) return false;
    for (let p = el; p instanceof Element; p = p.parentElement) {
      const s = getComputedStyle(p);
      if (p.hidden || s.display === "none" || s.visibility !== "visible" || Number(s.opacity) === 0) return false;
    }
    return true;
  };
  const v = selector => visible(one(selector));
  const main = one("#main-menu");
  const score = one("#stats1 #score");
  const errors = ["#connecting-content", "#disconnected", "#disconnect-content", ".disconnect-message"]
    .map(selector => one(selector)).filter(visible)
    .map(text).filter(x => /disconnected|another game opened|cannot connect|server (?:full|closed)|banned|error/i.test(x));
  // Do not return tokens, cookies, storage contents, emails, or profile names.
  let stored_auth_present = false, provider_active = false, provider_anonymous = false;
  try {
    stored_auth_present = Object.keys(localStorage).some(key =>
      /firebase:authUser|(?:^|[-_])(?:auth|session|token)(?:$|[-_])/i.test(key));
  } catch {}
  try {
    // Read-only observation of the site's existing auth provider; no getToken(),
    // no sign-in request, and no modification of game state.
    const f = window.firebase;
    const user = f && typeof f.auth === "function" && f.apps?.length ? f.auth().currentUser : null;
    provider_active = !!user?.uid;
    provider_anonymous = !!user?.isAnonymous;
  } catch {}
  const profile = v("#profile-btn");
  const account = one("#account-body");
  const logout_visible = Array.from(document.querySelectorAll("#account button, #account a, #main-menu button"))
    .filter(visible).some(e => /^(?:log\s*out|sign\s*out|ログアウト)$/i.test(text(e)));
  const account_panel_positive = visible(account) && text(account).length > 50 &&
    /level|statistics|experience|レベル|プロフィール|xp\b/i.test(text(account));
  const server = text(one("#current-server")).toLowerCase().replace(/^wss?:\/\//, "");
  const mode = text(one("#servers-content .server-option--mode.is-active .server-option__content"));
  const scoreText = visible(score) ? text(score) : "";
  // The mass counter may be shown as "2.4K" (or ":2.4K"), not plain digits.
  const parseMass = raw => {
    const m = String(raw || "").replace(/,/g, "").match(/(?:^|[:：\s])\s*(\d+(?:\.\d+)?)\s*([kKmMbB]?)(?=\s|$)/);
    if (!m) return null;
    const multiplier = {"": 1, k: 1000, m: 1000000, b: 1000000000}[m[2].toLowerCase()];
    return Number(m[1]) * multiplier;
  };
  const statsText = v("#stats1") ? text(one("#stats1")) : "";
  const statsKg = statsText.match(/(?:kg|mass)\s*[:：]?\s*([\d,.]+\s*[kKmMbB]?)/i);
  const ownMass = statsKg ? parseMass(statsKg[1]) : parseMass(scoreText);
  // Snay's public UI exposes #game-over and #respawn-button. The latter
  // need not be a semantic <button>, so role-only matching missed real deaths.
  const gameOverPanel = one("#game-over");
  const respawnControl = one("#respawn-button");
  const directGameOver = visible(gameOverPanel) && visible(respawnControl);
  // Conservatively support older/newer visible DOM without relying on game internals.
  const retryTextVisible = Array.from(document.querySelectorAll("button,[role=button],a,div,span"))
    .some(el => visible(el) && el.children.length <= 1 && /^try\s+again$/i.test(text(el)));
  const endHeading = Array.from(document.querySelectorAll("h1,h2,h3,strong,span,div"))
    .some(el => visible(el) && el.children.length <= 2 && text(el).length < 80 && /\bgame\s+over\b/i.test(text(el)));
  const gameOverVisible = directGameOver || (retryTextVisible && endHeading);
  const endPanel = gameOverVisible && visible(gameOverPanel) ? gameOverPanel :
    Array.from(document.querySelectorAll("div,section"))
      .find(el => visible(el) && /survive\s*time/i.test(text(el)) && text(el).length < 240);
  const survived = endPanel && text(endPanel).match(/survive\s*time\s*[:：]?\s*(\d+(?:\.\d+)?)\s*s/i);
  const own_score = ownMass;
  const challenge = /verify you are human|just a moment|access denied|checking your browser/i.test(document.title) ||
    Array.from(document.querySelectorAll('iframe[src*="challenges.cloudflare.com"], iframe[title*="challenge" i]')).some(visible);
  const loading = Array.from(document.querySelectorAll('[role="progressbar"],[aria-label="Loading the game"],#loading')).some(visible);
  return {
    origin_ok: /^https:\/\/(?:www\.)?snay\.io$/.test(location.origin),
    loading, profile_visible: profile, logout_visible, account_panel_positive,
    provider_active, provider_anonymous, stored_auth_present,
    login_form_visible: v('#login-content input[type="password"]'),
    play_visible: v("#main-menu #play-btn"), menu_visible: visible(main),
    server_menu_visible: v("#servers-content"), canvas_visible: v("#glcanvas"),
    hud_visible: v("#HUD"), spectator_visible: v("#spectator-mode") || v(".spectator-indicator"),
    game_over_visible: gameOverVisible, survival_seconds: survived ? Number(survived[1]) : null,
    own_score, error: errors.join(" | ").slice(0, 700), challenge,
    private_server: v("#private-server-content") || /private server/i.test(server),
    server, mode
  };
}
