"""SnayManager V2 ordinary-browser controller."""
__version__ = "2.1.2"
