"""SnayManager V2 ordinary-browser controller."""
__version__ = "2.2.2"
