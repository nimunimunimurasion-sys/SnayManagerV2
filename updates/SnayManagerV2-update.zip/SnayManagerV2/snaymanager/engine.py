from __future__ import annotations

import asyncio
import dataclasses
import time
from pathlib import Path
from typing import Callable

from .domain import (Config, Player, State, auth_verdict, counts, error_code,
                     slot_conclusion, spawn_positive)
from .site import Site, SiteProblem
from .storage import AuthVault, LocalLog, atomic_json, redact, snay_storage_only


class Manager:
    def __init__(self, directory: Path, emit: Callable[[str, dict], None]):
        self.directory = directory
        self.directory.mkdir(parents=True, exist_ok=True)
        self.emit = emit
        self.vault = AuthVault(directory / "auth.dpapi")
        self.log = LocalLog(directory / "logs")
        self.playwright = None
        self.browser = None
        self.login_context = None
        self.login_site = None
        self.auth_state = None
        self.authenticated = False
        self.manual_auth = False
        self.manual_candidates = False
        self.players: list[Player] = []
        self.sites: dict[int, Site] = {}
        self.contexts: dict[int, object] = {}
        self.session_context = None
        self.run_task = None
        self.monitor_task = None
        self.stop_event = asyncio.Event()
        self.halt_reason = ""
        self.peak = 0
        self.config = Config()
        self.closed = False
        self.run_id = ""
        self.active = False
        self.refresh_lock = asyncio.Lock()

    def message(self, event: str, **data):
        row = self.log.emit(event, **data)
        self.emit("log", row)

    def status(self):
        self.emit("players", {"rows": [p.public() for p in self.players], **counts(self.players),
                              "peak": self.peak, "halt_reason": self.halt_reason, "active": self.active})

    async def open_login(self, config: Config):
        config.validate()
        if self.active or any(p.opened for p in self.players):
            raise SiteProblem("STOP_FIRST", "先にSTOP ALLを押してください")
        if self.browser:
            if self.config.browser_channel != config.browser_channel or self.config.executable_path != config.executable_path:
                raise SiteProblem("RESTART", "ブラウザ種類を変更する場合はアプリを一度終了してください")
            if self.login_site and not self.login_site.page.is_closed():
                await self.login_site.page.bring_to_front()
                return
        if not self.playwright:
            from playwright.async_api import async_playwright
            self.playwright = await async_playwright().start()
        if not self.browser:
            kwargs = {"headless": False}
            if config.browser_channel == "chrome":
                kwargs["channel"] = "chrome"
            elif config.browser_channel == "executable":
                kwargs["executable_path"] = config.executable_path
            # Never use stealth, rotate fingerprints, ignore TLS, or disable auth.
            self.browser = await self.playwright.chromium.launch(**kwargs)
        self.config = config
        try:
            self.auth_state = self.vault.load()
        except Exception:
            self.auth_state = None
            self.message("auth_restore", result="復元できません。専用画面でログインが必要です")
        self.login_context = await self.browser.new_context(storage_state=self.auth_state)
        page = await self.login_context.new_page()
        self.login_site = Site(page, config)
        await self.login_site.navigate()
        self.authenticated = False
        self.manual_auth = False
        self.emit("auth", {"state": "確認待ち", "manual_allowed": False})
        self.message("login_open", result="専用ブラウザでログイン後、ログイン確認を押してください")

    async def verify_login(self):
        if not self.login_site:
            raise SiteProblem("OPEN_FIRST", "先にログイン画面を開いてください")
        result = await self.login_site.authenticate()
        self.authenticated = result == "AUTHENTICATED"
        self.manual_candidates = result == "PROBABLE"
        if self.authenticated:
            await self._save_auth()
        self.emit("auth", {"state": result, "manual_allowed": self.manual_candidates})
        self.message("auth_check", result=result)

    async def confirm_profile(self):
        if not self.login_site or not self.manual_candidates:
            raise SiteProblem("NO_PROFILE", "プロフィールの表示がまだ確認できません")
        e = await self.login_site.snapshot()
        if not e.profile_visible or e.provider_anonymous or e.challenge or e.loading:
            raise SiteProblem("NO_PROFILE", "画面のプロフィール状態が変わりました")
        self.authenticated = True
        self.manual_auth = True
        await self._save_auth()
        self.emit("auth", {"state": "本人がプロフィールを目視確認", "manual_allowed": False})
        self.message("auth_check", result="USER_CONFIRMED_PROFILE")

    async def _save_auth(self):
        if self.login_context:
            state = await self.login_context.storage_state(indexed_db=True)
            self.auth_state = snay_storage_only(state)
        if not self.auth_state:
            raise SiteProblem("AUTH_UNKNOWN", "保存できる認証状態がありません")
        saved = self.vault.save(self.auth_state)
        self.message("auth_storage", result="Windowsユーザー用に暗号化保存" if saved else "この環境ではメモリ内のみ")

    async def capture_arena(self):
        if not self.login_site:
            raise SiteProblem("OPEN_FIRST", "ログイン画面を開いて対象アリーナを選択してください")
        if not self.authenticated:
            raise SiteProblem("AUTH_UNKNOWN", "先にログイン確認を完了してください")
        if self.active or any(p.opened for p in self.players):
            raise SiteProblem("STOP_FIRST", "先にSTOP ALLを押してください")
        server, mode = await self.login_site.capture_arena()
        self.config = dataclasses.replace(self.config, server=server, mode=mode)
        self.emit("arena", {"server": server, "mode": mode})
        self.message("arena_capture", result="画面上のサーバーとモードを取得")

    async def start(self, config: Config, authorized: bool):
        config.validate(require_server=True)
        if not authorized:
            raise SiteProblem("PERMISSION_REQUIRED", "このアリーナ・方式・人数の許可を確認してください")
        if self.active or any(p.opened for p in self.players):
            raise SiteProblem("STOP_FIRST", "前の接続をSTOP ALLで閉じてから開始してください")
        if not self.authenticated or not self.auth_state or not self.browser:
            raise SiteProblem("AUTH_UNKNOWN", "有効なログイン状態を確認してください")
        if config.server != self.config.server or config.mode != self.config.mode:
            raise SiteProblem("ARENA_CHANGED", "アリーナを取得し直してから開始してください")
        if config.browser_channel != self.config.browser_channel or config.executable_path != self.config.executable_path:
            raise SiteProblem("RESTART", "ブラウザ設定を変更した場合はアプリを再起動してください")
        await self._save_auth()
        # A menu-only login tab can still hold a normal game socket. Close it
        # before the experiment so it cannot silently compete for a server slot.
        await self._close_login_context()
        self.config = config
        self.stop_event.clear()
        self.halt_reason = ""
        self.peak = 0
        self.run_id = str(time.time_ns())
        self.players = [Player(index=i, network=config.proxy_for(i).label,
                               context_mode=config.context_mode) for i in range(1, config.count + 1)]
        self.active = True
        self.status()
        self.message("run_start", run_id=self.run_id, count=config.count,
                     context_mode=config.context_mode, proxy_labels=[p.network for p in self.players])
        self.monitor_task = asyncio.create_task(self._monitor())
        self.run_task = asyncio.create_task(self._run())

    async def _close_login_context(self):
        if self.login_context:
            await self.login_context.close()
        self.login_context = None
        self.login_site = None
        self.emit("login_closed", {"reason": "接続枠の競合を避けるため、認証状態を保存してログイン用タブを終了"})

    async def _delay(self, seconds: float):
        try:
            await asyncio.wait_for(self.stop_event.wait(), seconds)
        except asyncio.TimeoutError:
            pass
        if self.stop_event.is_set():
            raise asyncio.CancelledError

    async def _new_site(self, player: Player) -> Site:
        if self.config.context_mode == "shared":
            if not self.session_context:
                self.session_context = await self.browser.new_context(storage_state=self.auth_state)
            context = self.session_context
        else:
            context = await self.browser.new_context(
                storage_state=self.auth_state, proxy=self.config.proxy_for(player.index).playwright())
            self.contexts[player.index] = context
        page = await context.new_page()
        player.opened = True
        site = Site(page, self.config)
        self.sites[player.index] = site
        return site

    async def _run(self):
        try:
            for player in self.players:
                if self.halt_reason or self.stop_event.is_set():
                    break
                if player.index > 1:
                    await self._delay(self.config.interval_seconds)
                player.state = State.OPENING
                self.status()
                try:
                    site = await self._new_site(player)
                    # Retry only transient navigation before PLAY. Never retry a
                    # server refusal, auth failure, challenge, or slot takeover.
                    for attempt in range(self.config.preplay_retries + 1):
                        try:
                            await site.navigate()
                            break
                        except Exception as exc:
                            if attempt >= self.config.preplay_retries:
                                raise SiteProblem("NAVIGATION_TIMEOUT", "画面読み込みに失敗。URLや機密情報はログに保存しません") from exc
                            e = await site.snapshot()
                            code = error_code(e.error, e.challenge)
                            if code:
                                raise SiteProblem(code, e.error or "アクセス確認")
                            self.message("preplay_retry", player=player.index, attempt=attempt + 1)
                            await self._delay(self.config.retry_delay_seconds)
                    player.state = State.LOGIN_WAIT
                    self.status()
                    verdict = await site.authenticate()
                    if verdict != "AUTHENTICATED":
                        e = await site.snapshot()
                        if not (self.manual_auth and verdict == "PROBABLE" and e.profile_visible):
                            raise SiteProblem("AUTH_UNVERIFIED",
                                f"復元したログインの有効性を確認できません（{verdict}）。PLAYしません")
                    if self.halt_reason:
                        break
                    player.state = State.SELECTING
                    self.status()
                    await site.select_arena()
                    # Selection may displace an older connection even before PLAY.
                    await self._refresh_all()
                    if self.halt_reason or self.stop_event.is_set():
                        break
                    player.state = State.PLAY_SENT
                    player.play_sent = True
                    self.status()
                    await site.play(player.index)
                    self.message("play_click", player=player.index, result="PLAY送信のみ。成功数には未計上")
                    deadline = time.monotonic() + self.config.spawn_timeout_seconds
                    respawns_seen = player.respawns
                    while time.monotonic() < deadline:
                        await self._refresh_all()
                        if self.halt_reason:
                            break
                        if player.respawns > respawns_seen:
                            respawns_seen = player.respawns
                            deadline = time.monotonic() + self.config.spawn_timeout_seconds
                        if player.state == State.DEAD and (not self.config.auto_respawn or
                                                           player.respawns >= self.config.respawn_limit):
                            self.halt_reason = "GAME_OVER_BEFORE_STABLE"
                            break
                        if all(p.state == State.SPAWNED for p in self.players[:player.index]):
                            break
                        await self._delay(self.config.monitor_seconds)
                    if self.halt_reason:
                        break
                    if player.state != State.SPAWNED:
                        if player.state in {State.DEAD, State.RESPAWNING}:
                            self.halt_reason = "GAME_OVER_BEFORE_STABLE"
                            player.code = "GAME_OVER"
                            player.detail = "PLAY後にGame Overを検出。生存中のスポーン確認は未成立です"
                        else:
                            player.state = State.UNVERIFIED
                            player.code = "SPAWN_UNVERIFIED"
                            player.detail = "生存確認に必要なスコア・表示・通信が揃いません（実際に未スポーンとは限りません）"
                            self.halt_reason = "SPAWN_UNVERIFIED"
                        break
                    self.message("spawn_verified", player=player.index,
                                 proof="PLAY後の自身スコア>0・ゲームUI・通常ゲーム通信の受信継続")
                    if player.index in {1, 2, 5, 10, 20}:
                        self.message("milestone", count=player.index, result="全対象を再確認し安定待ち")
                        await self._delay(self.config.stable_seconds)
                        await self._refresh_all()
                        if self.config.auto_respawn and not self.halt_reason:
                            # Give normal game-over retry a bounded chance to finish.
                            recovery_deadline = time.monotonic() + self.config.spawn_timeout_seconds + 3
                            while time.monotonic() < recovery_deadline and not self.halt_reason:
                                if all(p.state == State.SPAWNED for p in self.players[:player.index]):
                                    break
                                await self._delay(self.config.monitor_seconds)
                                await self._refresh_all()
                        if self.halt_reason or any(p.state != State.SPAWNED for p in self.players[:player.index]):
                            self.halt_reason = self.halt_reason or "GROUP_NOT_STABLE"
                            break
                except asyncio.CancelledError:
                    raise
                except SiteProblem as exc:
                    player.state = State.BLOCKED if exc.code in {
                        "NETWORK_SLOT_REPLACED", "SITE_CHALLENGE", "ACCESS_RESTRICTED", "RATE_LIMIT"} else State.FAILED
                    player.code, player.detail = exc.code, redact(str(exc))
                    self.halt_reason = exc.code
                    self.message("player_error", player=player.index, code=exc.code, detail=str(exc))
                    break
                except Exception as exc:
                    player.state, player.code = State.FAILED, "BROWSER_OPERATION_FAILED"
                    player.detail = "ブラウザ操作に失敗しました。アプリの起動環境／画面構造を確認してください"
                    self.halt_reason = player.code
                    self.message("player_error", player=player.index, code=player.code,
                                 exception_type=type(exc).__name__)
                    break
        except asyncio.CancelledError:
            self.halt_reason = self.halt_reason or "USER_STOP"
        finally:
            for player in self.players:
                if player.state == State.QUEUED:
                    player.state = State.SKIPPED
            self.active = False
            self.status()
            await self.export_report()
            self.message("launch_sequence_finished", **counts(self.players), peak=self.peak,
                         halt_reason=self.halt_reason or "指定数の起動処理を終了")

    async def _refresh_all(self):
        async with self.refresh_lock:
            await self._refresh_locked()

    async def _refresh_locked(self):
        now = time.monotonic()
        for player in self.players:
            site = self.sites.get(player.index)
            if not site or not player.opened:
                continue
            if player.state in {State.DISCONNECTED, State.FAILED, State.BLOCKED, State.STOPPED}:
                continue
            if site.page.is_closed():
                player.opened = False
                player.state, player.code = State.DISCONNECTED, "TAB_CLOSED"
                self.halt_reason = self.halt_reason or player.code
                continue
            try:
                e = await site.snapshot()
                code = error_code(e.error, e.challenge)
                if not player.play_sent and code == "DISCONNECTED":
                    # A failed default arena during initial navigation must not
                    # be mistaken for the selected arena's PLAY result.
                    continue
                # A generic disconnect message can be a leftover from the
                # initial arena. Re-check it for up to 4 seconds after PLAY.
                # This never treats the socket as connected or a spawn as
                # verified; a persistent error still stops the run.
                if (code == "DISCONNECTED" and player.play_sent and
                        getattr(site, "preplay_error", "") and
                        e.error == site.preplay_error):
                    # The old default-arena error can remain in the DOM even
                    # after ordinary game UI is visibly running. Strong live
                    # evidence or a real Game Over supersedes this stale label.
                    live = (e.own_score is not None and e.own_score > 0 and
                            e.hud_visible and e.canvas_visible and
                            not e.menu_visible and not e.play_visible and
                            not e.spectator_visible and site.wire.open and
                            site.frames_after_play > 0 and
                            now - site.wire.last_received_at <= 5.0)
                    if e.game_over_visible or live:
                        e = dataclasses.replace(e, error="")
                        code = ""
                    elif now - getattr(site, "play_started_at", 0.0) < 4.0:
                        # A genuine error that persists after PLAY still
                        # results in DISCONNECTED, without unbounded retries.
                        continue
                if code:
                    player.state, player.code = State.DISCONNECTED, code
                    player.detail = slot_conclusion() if code == "NETWORK_SLOT_REPLACED" else redact(e.error or code)
                    if self.halt_reason != code:
                        self.message("connection_loss", player=player.index, code=code, detail=player.detail)
                    self.halt_reason = code
                    continue
                if not player.play_sent:
                    continue
                if e.game_over_visible:
                    # After clicking Try Again, a transitional Game Over frame
                    # can persist briefly. Do not spend all retries on one death.
                    if (player.state == State.PLAY_SENT and player.respawns > 0
                            and now - player.last_respawn_at < 4.0):
                        continue
                    if player.state not in {State.DEAD, State.RESPAWNING}:
                        player.deaths += 1
                        player.ever_spawned = bool(e.survival_seconds and e.survival_seconds > 0) or player.ever_spawned
                        player.update_spawn(False, now, self.config.stable_seconds)
                        player.state, player.code = State.DEAD, "GAME_OVER"
                        player.detail = (f"Game Over（生存 {e.survival_seconds:g} 秒）。死亡中はスポーン数に含めません"
                                         if e.survival_seconds is not None else
                                         "Game Over。死亡中はスポーン数に含めません")
                        self.message("game_over", player=player.index, survived=e.survival_seconds)
                    continue
                positive = spawn_positive(e, play_sent=site.play_sent, socket_open=site.wire.open,
                                           received_after_play=site.frames_after_play) and (
                    now - site.wire.last_received_at <= max(5, self.config.monitor_seconds * 3))
                was_verified = player.state == State.SPAWNED
                player.update_spawn(positive, now, self.config.stable_seconds)
                if not positive:
                    if was_verified:
                        player.code = "EVIDENCE_PENDING"
                        player.detail = "一時的に生存証拠を確認できません。死亡画面か切断かを再確認中"
                    if (player.evidence_lost_since is not None and
                            now - player.evidence_lost_since >= 6):
                        player.code = "SPAWN_EVIDENCE_LOST"
                        player.detail = "6秒以上、生存を確認できません。接続・死亡・メニューを確認してください"
                        self.halt_reason = self.halt_reason or player.code
                    if site.wire.closed_count and not site.wire.open:
                        player.state, player.code = State.DISCONNECTED, "GAME_SOCKET_CLOSED"
                        self.halt_reason = self.halt_reason or player.code
            except SiteProblem as exc:
                if not player.play_sent and exc.code in {"WRONG_PAGE", "TAB_CLOSED"}:
                    continue
                player.state, player.code = State.DISCONNECTED, exc.code
                self.halt_reason = self.halt_reason or exc.code
            except Exception:
                # A destroyed/navigating JS context is UNKNOWN, never retained as success.
                player.update_spawn(False, now, self.config.stable_seconds)
        verified = counts(self.players)["spawn_verified_now"]
        self.peak = max(self.peak, verified)
        self.status()

    async def _monitor(self):
        try:
            while not self.stop_event.is_set():
                await self._refresh_all()
                if self.config.auto_respawn and not self.halt_reason:
                    for player in self.players:
                        if player.state == State.DEAD and player.respawns < self.config.respawn_limit:
                            # Ordinary game-over retry, never recover a dropped/blocked socket.
                            player.state = State.RESPAWNING
                            player.code = ""
                            player.detail = "通常のTry Againで再スポーンを試行中"
                            self.status()
                            await self._delay(2.0)
                            try:
                                await self.sites[player.index].retry_after_death()
                                player.respawns += 1
                                player.last_respawn_at = time.monotonic()
                                player.evidence_since = None
                                player.state = State.PLAY_SENT
                                self.message("respawn_click", player=player.index,
                                             attempt=player.respawns, limit=self.config.respawn_limit)
                            except SiteProblem as exc:
                                player.state, player.code, player.detail = State.DEAD, exc.code, redact(str(exc))
                                self.halt_reason = exc.code
                            except Exception as exc:
                                player.state, player.code = State.DEAD, "RESPAWN_FAILED"
                                player.detail = "Try Again操作に失敗しました"
                                self.halt_reason = "RESPAWN_FAILED"
                                self.message("respawn_error", player=player.index, exception_type=type(exc).__name__)
                            self.status()
                await self._delay(self.config.monitor_seconds)
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            self.halt_reason = "MONITOR_ERROR"
            for player in self.players:
                player.update_spawn(False, time.monotonic(), self.config.stable_seconds)
            self.message("monitor_error", exception_type=type(exc).__name__)
            self.status()

    async def stop_all(self):
        self.stop_event.set()
        # Cancel polling / queued clicks before closing all player contexts.
        tasks = [t for t in (self.run_task, self.monitor_task) if t and not t.done()]
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        await asyncio.gather(*(asyncio.wait_for(site.page.close(run_before_unload=False), 4)
                               for site in list(self.sites.values())), return_exceptions=True)
        contexts = list(self.contexts.values()) + ([self.session_context] if self.session_context else [])
        await asyncio.gather(*(asyncio.wait_for(context.close(), 5) for context in contexts), return_exceptions=True)
        try:
            await asyncio.wait_for(self._close_login_context(), 5)
        except Exception as exc:
            self.message("login_close_failed", exception_type=type(exc).__name__)
        for player in self.players:
            site = self.sites.get(player.index)
            player.opened = bool(site and not site.page.is_closed())
            if player.opened:
                player.state = State.FAILED
                player.code = "STOP_FAILED"
                player.detail = "終了を確認できません。専用ブラウザ側でタブを閉じてください"
                self.message("stop_failed", player=player.index, code=player.code)
                continue
            self.sites.pop(player.index, None)
            self.contexts.pop(player.index, None)
            if player.state not in {State.FAILED, State.BLOCKED, State.DISCONNECTED, State.SKIPPED}:
                player.state = State.STOPPED
        if not self.sites:
            self.session_context = None
        self.active = False
        self.status()
        await self.export_report()
        self.message("stop_all", tabs_still_open=sum(p.opened for p in self.players),
                     result="終了確認済みのタブのみ停止数に反映。認証状態はPC内に保存")

    async def export_report(self):
        report = {
            "version": "2.0.0", "run_id": self.run_id,
            "environment": "actual-browser" if self.run_id else "not-run",
            "counts": counts(self.players), "peak_verified_simultaneously": self.peak,
            "halt_reason": self.halt_reason,
            "slot_analysis": slot_conclusion() if self.halt_reason == "NETWORK_SLOT_REPLACED" else "",
            "config": {"count": self.config.count, "mode": self.config.mode, "server": self.config.server,
                       "context_mode": self.config.context_mode,
                       "networks": [p.network for p in self.players]},
            "players": [p.public() for p in self.players],
            "auth_method": "manual-profile" if self.manual_auth else "positive-auth-signals",
            "limitations": [
                "tab数とPLAY送信数はスポーン確認数と別",
                "実行結果は表示UIと通常通信の受信に基づく。サーバー内部の枠判定キーは不明",
                "別経路でも同一の公開IPとなる場合がある。IP確認サービスへの送信は行わない",
                "制限検出後の自動経路変更・再接続は行わない",
            ],
        }
        path = self.directory / "last-report.json"
        atomic_json(path, report)
        if self.run_id:
            atomic_json(self.directory / "reports" / (self.run_id + ".json"), report)
        self.emit("report", {"path": str(path)})
        return path

    async def compare_history(self):
        paths = sorted((self.directory / "reports").glob("*.json"))[-12:]
        import json
        rows = []
        for path in paths:
            try:
                report = json.loads(path.read_text(encoding="utf-8"))
                rows.append({key: report.get(key) for key in
                             ("run_id", "config", "peak_verified_simultaneously", "halt_reason")})
            except (ValueError, OSError):
                continue
        comparison = {
            "runs": rows,
            "interpretation": (
                "shared/isolatedの違い・固定経路ごとの結果は比較できますが、"
                "経路labelの違いは異なる公開IPの証拠ではありません。"
                "同一アカウントのみの試験ではアカウント制限とIP制限を完全に切り分けられません。"
                "サーバー側の枠判定を確定するには運営側の設定／ログが必要です。"
            ),
        }
        path = self.directory / "comparison.json"
        atomic_json(path, comparison)
        for row in rows:
            self.message("comparison", mode=row.get("config", {}).get("context_mode"),
                         networks=row.get("config", {}).get("networks"),
                         peak=row.get("peak_verified_simultaneously"), reason=row.get("halt_reason"))
        self.message("comparison_note", detail=comparison["interpretation"])
        return path

    async def shutdown(self):
        await self.stop_all()
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()
        self.closed = True
