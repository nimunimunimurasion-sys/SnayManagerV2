from __future__ import annotations

import dataclasses
import re
import time
from enum import StrEnum
from urllib.parse import urlsplit


class State(StrEnum):
    QUEUED = "待機"
    OPENING = "ブラウザ起動中"
    LOGIN_WAIT = "ログイン確認中"
    SELECTING = "アリーナ選択中"
    PLAY_SENT = "PLAY送信済み"
    UNVERIFIED = "スポーン未確認"
    SPAWNED = "スポーン確認"
    DEAD = "死亡（Game Over）"
    RESPAWNING = "再スポーン中"
    DISCONNECTED = "切断"
    FAILED = "失敗"
    BLOCKED = "制限で停止"
    STOPPED = "停止済み"
    SKIPPED = "未実行"


SLOT_MESSAGE = "ANOTHER GAME OPENED FROM YOUR NETWORK TOOK THIS SLOT"
MILESTONES = (1, 2, 5, 10, 20)


def normalize_server(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"^wss?://", "", value)
    match = re.fullmatch(r"[a-z0-9-]+\.snay\.io/ws\?port=(\d{1,5})", value)
    if not match or not 1 <= int(match[1]) <= 65535:
        raise ValueError("サーバーは eu-1.snay.io/ws?port=8092 のように入力してください")
    return value


@dataclasses.dataclass(frozen=True)
class Proxy:
    server: str = ""
    username_env: str = ""
    password_env: str = ""
    label: str = "direct"

    @classmethod
    def from_dict(cls, value: dict) -> Proxy:
        if not isinstance(value, dict):
            raise ValueError("プロキシ行はJSONオブジェクトにしてください")
        result = cls(**value)
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,40}", result.label):
            raise ValueError("プロキシlabelは英数字・ハイフン・アンダースコアのみです")
        if result.server:
            url = urlsplit(result.server)
            if (url.scheme not in {"http", "https", "socks5"} or not url.hostname
                    or url.username or url.password or url.path not in {"", "/"}
                    or url.query or url.fragment):
                raise ValueError("プロキシは http://host:port 等。認証は環境変数で指定してください")
            try:
                if not url.port:
                    raise ValueError
            except ValueError as exc:
                raise ValueError("プロキシのportが不正です") from exc
        for env in (result.username_env, result.password_env):
            if env and not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,79}", env):
                raise ValueError("プロキシ認証の環境変数名が不正です")
        return result

    def playwright(self) -> dict | None:
        import os
        if not self.server:
            return None
        result = {"server": self.server}
        for field, name in (("username", self.username_env), ("password", self.password_env)):
            if name:
                if not os.environ.get(name):
                    raise ValueError(f"プロキシ認証用の環境変数 {name} が設定されていません")
                result[field] = os.environ[name]
        return result


@dataclasses.dataclass(frozen=True)
class Config:
    count: int = 2
    connection_mode: str = "accounts"  # accounts | guest_probe (ordinary public UI only)
    interval_seconds: float = 3.0
    auth_timeout_seconds: float = 40.0
    navigation_timeout_seconds: float = 40.0
    spawn_timeout_seconds: float = 25.0
    stable_seconds: float = 5.0
    monitor_seconds: float = 1.0
    preplay_retries: int = 1
    retry_delay_seconds: float = 5.0
    context_mode: str = "shared"
    browser_channel: str = "chrome"
    executable_path: str = ""
    server: str = ""
    mode: str = ""
    nickname_prefix: str = "SMV2"
    auto_respawn: bool = True
    respawn_limit: int = 3
    proxies: tuple[Proxy, ...] = ()

    @classmethod
    def from_dict(cls, data: dict) -> Config:
        data = dict(data)
        data["proxies"] = tuple(Proxy.from_dict(row) for row in data.get("proxies", []))
        result = cls(**data)
        result.validate()
        return result

    def validate(self, require_server: bool = False) -> None:
        if isinstance(self.count, bool) or not isinstance(self.count, int) or not 1 <= self.count <= 20:
            raise ValueError("生成数は1〜20で指定してください")
        bounds = {
            "interval_seconds": (1, 60), "auth_timeout_seconds": (5, 180),
            "navigation_timeout_seconds": (5, 180), "spawn_timeout_seconds": (5, 120),
            "stable_seconds": (2, 60), "monitor_seconds": (0.5, 10),
            "retry_delay_seconds": (2, 60),
        }
        for field, (minimum, maximum) in bounds.items():
            value = getattr(self, field)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not minimum <= value <= maximum:
                raise ValueError(f"{field} は {minimum}〜{maximum} 秒で指定してください")
        if type(self.preplay_retries) is not int or not 0 <= self.preplay_retries <= 2:
            raise ValueError("PLAY前の再読み込みは0〜2回です")
        if type(self.auto_respawn) is not bool or type(self.respawn_limit) is not int or not 0 <= self.respawn_limit <= 10:
            raise ValueError("死亡時自動再スポーンは真偽値、再試行上限は0〜10回")
        if self.connection_mode not in {"accounts", "guest_probe"}:
            raise ValueError("接続方式は accounts / guest_probe のいずれか")
        if self.context_mode not in {"shared", "isolated"}:
            raise ValueError("context_mode は shared / isolated のどちらかです")
        if self.browser_channel not in {"chrome", "chromium", "executable"}:
            raise ValueError("ブラウザは chrome / chromium / executable のどれかです")
        if self.browser_channel == "executable" and not self.executable_path:
            raise ValueError("ブラウザの実行ファイルを指定してください")
        if self.server:
            normalize_server(self.server)
        if require_server and (not self.server or not self.mode.strip()):
            raise ValueError("ログイン後、「現在のアリーナを取得」で対象を確認してください")
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,14}", self.nickname_prefix):
            raise ValueError("テスト名の接頭辞は英数字等14文字以内です")
        if len(self.proxies) not in {0, self.count}:
            raise ValueError("プロキシ行数は0または生成数と同じ数にしてください（自動割当なし）")
        if self.proxies and self.context_mode != "isolated":
            raise ValueError("プレイヤー別のネットワークは「独立コンテキスト」でのみ使用できます")
        labels = [proxy.label for proxy in self.proxies]
        if len(set(labels)) != len(labels):
            raise ValueError("各ネットワークのlabelを重複させないでください")

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)

    def proxy_for(self, index: int) -> Proxy:
        return self.proxies[index - 1] if self.proxies else Proxy()


@dataclasses.dataclass
class Evidence:
    origin_ok: bool = False
    loading: bool = False
    profile_visible: bool = False
    logout_visible: bool = False
    provider_active: bool = False
    provider_anonymous: bool = False
    stored_auth_present: bool = False
    login_form_visible: bool = False
    account_panel_positive: bool = False
    play_visible: bool = True
    menu_visible: bool = True
    server_menu_visible: bool = False
    canvas_visible: bool = False
    hud_visible: bool = False
    spectator_visible: bool = False
    game_over_visible: bool = False
    survival_seconds: float | None = None
    own_score: float | None = None
    error: str = ""
    challenge: bool = False
    private_server: bool = False
    server: str = ""
    mode: str = ""

    @classmethod
    def from_dict(cls, data: dict) -> Evidence:
        allowed = {field.name for field in dataclasses.fields(cls)}
        return cls(**{key: value for key, value in data.items() if key in allowed})


def auth_verdict(e: Evidence) -> tuple[str, str]:
    if not e.origin_ok:
        return "UNKNOWN", "対象サイト外"
    if e.challenge:
        return "BLOCKED", "人間確認・アクセス制限"
    if e.loading:
        return "PENDING", "画面読み込み中"
    # Positive evidence wins over a stale LOGIN label.
    if not e.provider_anonymous and (e.provider_active or
            (e.profile_visible and (e.logout_visible or e.account_panel_positive))):
        return "AUTHENTICATED", "プロフィール／認証プロバイダーで確認"
    if e.profile_visible:
        return "PROBABLE", "プロフィールあり。認証内容の確認待ち"
    if e.stored_auth_present:
        return "PENDING", "保存済み認証の復元待ち（有効性は未確認）"
    if e.login_form_visible:
        return "SIGNIN_REQUIRED", "ログインフォーム表示中"
    return "UNKNOWN", "認証状態をまだ確認できません"


def error_code(text: str, challenge: bool = False) -> str:
    if challenge:
        return "SITE_CHALLENGE"
    upper = " ".join(text.upper().split())
    if "YOUR ACCOUNT JUST CONNECTED FROM ANOTHER TAB OR DEVICE" in upper:
        return "ACCOUNT_SESSION_REPLACED"
    if SLOT_MESSAGE in upper:
        return "NETWORK_SLOT_REPLACED"
    if re.search(r"\b(?:TOO MANY REQUESTS|RATE LIMIT|HTTP 429)\b", upper):
        return "RATE_LIMIT"
    if re.search(r"\b(?:BANNED|ACCESS DENIED|FORBIDDEN)\b", upper):
        return "ACCESS_RESTRICTED"
    if re.search(r"\b(?:DISCONNECTED|CANNOT CONNECT|CONNECTION LOST|ERROR)\b", upper):
        return "DISCONNECTED"
    return ""


def spawn_positive(e: Evidence, *, play_sent: bool, socket_open: bool,
                   received_after_play: int) -> bool:
    # "RENDERED: cells" is world-render count, not the player's own cells.
    # Never use it as spawn proof. Likewise canvas visibility alone is insufficient.
    return bool(e.origin_ok and play_sent and socket_open and received_after_play > 0
                and e.own_score is not None and e.own_score > 0 and e.hud_visible
                and e.canvas_visible and not e.play_visible and not e.menu_visible
                and not e.server_menu_visible and not e.spectator_visible and not e.game_over_visible
                and not e.loading and not e.error and not e.challenge)


@dataclasses.dataclass
class Player:
    index: int
    state: State = State.QUEUED
    network: str = "direct"
    context_mode: str = "shared"
    account: str = "main"
    opened: bool = False
    play_sent: bool = False
    ever_verified: bool = False
    ever_spawned: bool = False
    deaths: int = 0
    respawns: int = 0
    last_respawn_at: float = 0.0
    evidence_since: float | None = None
    evidence_lost_since: float | None = None
    last_verified_at: float | None = None
    code: str = ""
    detail: str = ""

    def update_spawn(self, positive: bool, now: float, stable_seconds: float) -> bool:
        if not positive:
            self.evidence_since = None
            if self.state == State.SPAWNED:
                self.evidence_lost_since = now
                self.state = State.UNVERIFIED
            return False
        self.evidence_lost_since = None
        if self.evidence_since is None:
            self.evidence_since = now
        if now - self.evidence_since >= stable_seconds:
            self.state = State.SPAWNED
            self.ever_verified = True
            self.ever_spawned = True
            self.last_verified_at = now
            return True
        return False

    def public(self) -> dict:
        return dataclasses.asdict(self)


def counts(players: list[Player]) -> dict:
    return {
        "tabs_open": sum(p.opened for p in players),
        "spawn_verified_now": sum(p.state == State.SPAWNED for p in players),
        "unverified": sum(p.state in {State.UNVERIFIED, State.PLAY_SENT, State.RESPAWNING} for p in players),
        "dead": sum(p.state == State.DEAD for p in players),
        "failed": sum(p.state in {State.FAILED, State.DISCONNECTED, State.BLOCKED} for p in players),
        "play_sent": sum(p.play_sent for p in players),
    }


def slot_conclusion() -> str:
    return ("ネットワーク起点の接続枠が別ゲームに置き換わった旨の通知を受信。"
            "IP・アカウント・セッションのどれが判定キーかは未確定。"
            "自動再接続／自動経路変更は停止。運営の枠設定・検証用許可を確認してください。")
