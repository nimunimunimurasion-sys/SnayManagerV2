from __future__ import annotations

import asyncio
import re
import time
from pathlib import Path
from urllib.parse import urlsplit

from .domain import Config, Evidence, auth_verdict, error_code, normalize_server

SITE = "https://www.snay.io/"
SNAPSHOT = (Path(__file__).parent / "assets" / "snapshot.js").read_text(encoding="utf-8")


class SiteProblem(Exception):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)


class Wire:
    """Observe the *ordinary* game browser sockets, never send or decode packets."""
    def __init__(self, page):
        self.sockets = set()
        self.frames = 0
        self.last_received_at = 0.0
        self.closed_count = 0
        page.on("websocket", self._opened)

    def _opened(self, socket):
        try:
            url = urlsplit(socket.url)
            if not (url.hostname and (url.hostname == "snay.io" or url.hostname.endswith(".snay.io"))
                    and url.scheme in {"ws", "wss"} and url.path == "/ws"):
                return
        except ValueError:
            return
        self.sockets.add(socket)
        socket.on("framereceived", lambda _: self._frame())
        socket.on("close", lambda *_: self._closed(socket))

    def _frame(self):
        self.frames += 1
        self.last_received_at = time.monotonic()

    def _closed(self, socket):
        self.sockets.discard(socket)
        self.closed_count += 1

    @property
    def open(self):
        return bool(self.sockets)


class Site:
    def __init__(self, page, config: Config):
        self.page = page
        self.config = config
        self.page.set_default_timeout(12000)
        self.page.set_default_navigation_timeout(config.navigation_timeout_seconds * 1000)
        self.wire = Wire(page)
        self.frames_at_play = 0
        self.positive_auth_seen = False
        self.manual_auth = False
        self.play_sent = False
        self.opened_profile = False
        # The site can display a generic disconnect from its default arena
        # while the user-selected arena is ready. Keep this evidence separate
        # from errors that arrive *after* PLAY.
        self.preplay_error = ""
        self.play_started_at = 0.0

    async def snapshot(self) -> Evidence:
        if self.page.is_closed():
            raise SiteProblem("TAB_CLOSED", "ブラウザタブが閉じられました")
        if urlsplit(self.page.url).netloc not in {"snay.io", "www.snay.io"}:
            raise SiteProblem("WRONG_PAGE", "Snay.ioの画面ではありません")
        return Evidence.from_dict(await self.page.evaluate(SNAPSHOT))

    async def navigate(self):
        # Navigating the official UI is the only way we initiate a game connection.
        await self.page.goto(SITE, wait_until="domcontentloaded")

    async def authenticate(self) -> str:
        """Do not infer authentication failure from the LOGIN button label."""
        end = time.monotonic() + self.config.auth_timeout_seconds
        last = "UNKNOWN"
        while time.monotonic() < end:
            e = await self.snapshot()
            last, _ = auth_verdict(e)
            if last == "BLOCKED":
                raise SiteProblem("SITE_CHALLENGE", "人間確認・アクセス制限。操作を停止します")
            if last == "AUTHENTICATED":
                self.positive_auth_seen = True
                return last
            if last == "PROBABLE" and not self.opened_profile:
                # Opening the existing public profile UI adds positive account
                # evidence. It neither fills credentials nor changes account data.
                profile = self.page.locator("#profile-btn")
                if await profile.is_visible():
                    await profile.click()
                    self.opened_profile = True
            await asyncio.sleep(0.4)
        # UNKNOWN/PENDING remain UNKNOWN, not a false "not logged in".
        return last

    async def close_profile(self):
        close = self.page.locator("#account button.windowclosebtn")
        if await close.count() == 1 and await close.is_visible():
            await close.click()

    async def capture_arena(self) -> tuple[str, str]:
        await self.close_profile()
        current = await self.snapshot()
        if current.private_server:
            raise SiteProblem("PRIVATE_SERVER", "プライベートサーバーはこのログイン方式の対象外です")
        # Opening the normal server picker only; never type a websocket URL into internals.
        if not current.server_menu_visible:
            await self.page.locator("#main-menu button.Server-btn").click()
        await self.page.locator("#servers-content .server-option--mode.is-active").wait_for(state="visible")
        current = await self.snapshot()
        if not current.server:
            raise SiteProblem("CHOOSE_ARENA", "Chromeで対象のアリーナを選択してから取得してください")
        server = normalize_server(current.server)
        arena_code = server.rsplit("=", 1)[1]
        candidates = self.page.locator("#servers-content button.server-entry").filter(
            has_text=re.compile(r"Arena code:\s*" + re.escape(arena_code) + r"(?!\d)", re.I))
        if await candidates.count() != 1 or not current.mode:
            raise SiteProblem("CHOOSE_ARENA", "現在のサーバーに対応するモードを選択してください")
        await self.page.locator("#servers-content button.windowclosebtn").click()
        return server, current.mode

    async def select_arena(self):
        await self.close_profile()
        e = await self.snapshot()
        if e.challenge:
            raise SiteProblem("SITE_CHALLENGE", "人間確認・アクセス制限")
        if e.private_server:
            raise SiteProblem("PRIVATE_SERVER", "プライベートサーバーはログイン方式の対象外")
        if error_code(e.error, e.challenge) == "NETWORK_SLOT_REPLACED":
            raise SiteProblem("NETWORK_SLOT_REPLACED", e.error)
        if e.server == self.config.server and not e.server_menu_visible:
            return
        if not e.server_menu_visible:
            try:
                await self.page.locator("#main-menu button.Server-btn").click()
            except Exception as exc:
                raise SiteProblem("SERVER_MENU_TIMEOUT", "サーバー一覧を開けません。サイトの画面更新・表示状態を確認してください") from exc
        # The default mode can already match. Clicking the already-selected
        # mode causes an unnecessary UI re-render and occasionally a timeout.
        current = await self.snapshot()
        if current.mode.strip().casefold() != self.config.mode.strip().casefold():
            mode = self.page.locator("#servers-content button.server-option--mode").filter(
                has=self.page.locator(".server-option__content").filter(
                    has_text=re.compile(r"^\s*" + re.escape(self.config.mode) + r"\s*$", re.I)))
            if await mode.count() != 1:
                mode = self.page.locator("#servers-content button.server-option--mode").filter(
                    has_text=re.compile(r"^\s*" + re.escape(self.config.mode) + r"\s*(?:\d+ players)?\s*$", re.I))
            if await mode.count() != 1:
                raise SiteProblem("ARENA_NOT_FOUND", f"モード「{self.config.mode}」を一意に見つけられません")
            try:
                await mode.click(timeout=12000)
            except Exception as exc:
                raise SiteProblem("MODE_CLICK_TIMEOUT", f"モード「{self.config.mode}」の選択でタイムアウトしました") from exc
        code = self.config.server.rsplit("=", 1)[1]
        row = self.page.locator("#servers-content button.server-entry").filter(
            has_text=re.compile(r"Arena code:\s*" + re.escape(code) + r"(?!\d)", re.I))
        try:
            await row.wait_for(state="visible", timeout=12000)
            label = await row.inner_text(timeout=12000)
        except Exception as exc:
            raise SiteProblem("SERVER_ROW_TIMEOUT", f"アリーナ番号 {code} がサーバー一覧で見つかりません。選んだモード: {self.config.mode}") from exc
        capacity = re.search(r"(\d+)\s*/\s*(\d+)\s*players", label, re.I)
        if (not await row.is_enabled() or re.search(r"\b(FULL|CLOSED|OFFLINE)\b", label, re.I)
                or capacity and int(capacity[1]) >= int(capacity[2])):
            raise SiteProblem("SERVER_FULL", "アリーナが満員または閉鎖中")
        if not re.search(r"\b(OPEN|ACTIVE)\b", label, re.I):
            raise SiteProblem("ARENA_UNKNOWN", "アリーナの受付状態を確認できません")
        try:
            await row.click(timeout=12000)
        except Exception as exc:
            raise SiteProblem("SERVER_CLICK_TIMEOUT", f"アリーナ番号 {code} の選択でタイムアウトしました") from exc
        end = time.monotonic() + self.config.navigation_timeout_seconds
        while time.monotonic() < end:
            e = await self.snapshot()
            code = error_code(e.error, e.challenge)
            # DISCONNECTED can be left over from the site's initial/default
            # server connection. Selection alone does not send PLAY, so this
            # does not prove the requested arena refused a player.
            if code and code != "DISCONNECTED":
                raise SiteProblem(code, e.error or "人間確認")
            if e.server == self.config.server and not e.server_menu_visible and e.play_visible:
                return
            await asyncio.sleep(0.3)
        raise SiteProblem("ARENA_MISMATCH", "対象サーバーを選択できません。PLAY画面の状態を確認してください")

    async def play(self, index: int):
        if self.play_sent:
            raise SiteProblem("NO_REPLAY", "PLAY後の再試行は禁止です")
        e = await self.snapshot()
        code = error_code(e.error, e.challenge)
        # Server-side restrictions are never ignored. A generic disconnect
        # already present before PLAY may describe the initial/default socket.
        if code and code != "DISCONNECTED":
            raise SiteProblem(code, e.error or "人間確認")
        if e.server != self.config.server or e.server_menu_visible or not e.play_visible or not e.menu_visible:
            raise SiteProblem("ARENA_MISMATCH", "PLAY前のサーバー／画面確認に失敗")
        # Capture the original warning *before* closing the dialog. Earlier
        # releases lost this fingerprint when the UI cleared after dismissal,
        # and the very same stale warning was then treated as a new refusal.
        preplay_warning = e.error if code == "DISCONNECTED" else ""
        if code == "DISCONNECTED":
            # A normal UI dismissal is permitted; never forcibly click through
            # a blocking server error, challenge, or access restriction.
            for selector in ("#disconnected .windowclosebtn", "#disconnect-content .windowclosebtn",
                             "#connecting-content .windowclosebtn"):
                close = self.page.locator(selector)
                if await close.count() == 1 and await close.is_visible():
                    await close.click(timeout=3000)
                    break
            e = await self.snapshot()
            code = error_code(e.error, e.challenge)
            if code and code != "DISCONNECTED":
                raise SiteProblem(code, e.error or "人間確認")
            if e.server != self.config.server or e.server_menu_visible or not e.play_visible:
                raise SiteProblem("ARENA_MISMATCH", "切断表示の確認後、PLAY画面が変化しました")
        self.preplay_error = preplay_warning
        self.stale_warning_reported = False
        nick = self.page.locator('input#nick, input[name="nick"], input[placeholder="nick"]')
        if await nick.count() == 1 and await nick.is_visible():
            await nick.fill(f"{self.config.nickname_prefix}-{index:02d}")
        self.frames_at_play = self.wire.frames
        self.play_started_at = time.monotonic()
        # Mark BEFORE the click: timeout could occur after the server receives it.
        self.play_sent = True
        await self.page.locator("#main-menu #play-btn").click()

    @property
    def frames_after_play(self):
        return max(0, self.wire.frames - self.frames_at_play)

    async def retry_after_death(self):
        """Press only the game's visible normal Try Again button (bounded by manager)."""
        e = await self.snapshot()
        if not e.game_over_visible:
            raise SiteProblem("NO_GAME_OVER", "死亡画面ではないため再スポーン操作を中止")
        code = error_code(e.error, e.challenge)
        if code:
            raise SiteProblem(code, e.error or "アクセス確認")
        # The actual Snay UI uses #respawn-button, which may not expose
        # button role / exact text in the accessibility tree.
        retry = self.page.locator("#respawn-button")
        if await retry.count() != 1 or not await retry.is_visible():
            retry = self.page.get_by_role("button", name=re.compile(r"^\s*Try\s+Again\s*$", re.I))
        if await retry.count() != 1 or not await retry.is_visible():
            retry = self.page.get_by_text(re.compile(r"^\s*Try\s+Again\s*$", re.I))
        if await retry.count() != 1 or not await retry.is_visible():
            raise SiteProblem("RETRY_BUTTON_NOT_FOUND", "Game Overは確認できましたがTry Againボタンが見つかりません")
        self.frames_at_play = self.wire.frames
        await retry.click(timeout=10000)
        # The new spawn must be verified again; do not carry over past evidence.
        self.play_sent = True
