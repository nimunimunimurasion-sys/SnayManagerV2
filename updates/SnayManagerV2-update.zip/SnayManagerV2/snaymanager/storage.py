from __future__ import annotations

import ctypes
import json
import os
import re
import tempfile
from datetime import datetime, timezone
from pathlib import Path


def data_dir() -> Path:
    base = Path(os.environ.get("LOCALAPPDATA") or Path.home() / ".local" / "share")
    result = base / "SnayManagerV2"
    result.mkdir(parents=True, exist_ok=True)
    return result


def atomic_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(dir=path.parent, prefix=path.name + ".")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as output:
            json.dump(data, output, ensure_ascii=False, indent=2)
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


def redact(text: str) -> str:
    text = re.sub(r"\b[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{8,}", "<JWT>", str(text))
    text = re.sub(r"(?i)((?:password|passwd|token|authorization|cookie|secret|sessionid)"
                  r'["\s]*[:=]\s*)(?:"[^"]*"|[^\s,;]+)', r"\1<redacted>", text)
    text = re.sub(r"(?:https?|wss?|socks5)://[^\s\"<>]+", "<URL>", text)
    text = re.sub(r"\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b", "<email>", text)
    return text[:1400]


class LocalLog:
    def __init__(self, directory: Path):
        directory.mkdir(parents=True, exist_ok=True)
        self.path = directory / ("run-" + datetime.now().strftime("%Y%m%d-%H%M%S-%f") + ".jsonl")

    def emit(self, event: str, **data) -> dict:
        def clean(value):
            if isinstance(value, dict):
                return {str(k): "<redacted>" if re.search("token|cookie|password|secret|credential", str(k), re.I)
                        else clean(v) for k, v in value.items()}
            if isinstance(value, (list, tuple)):
                return [clean(x) for x in value]
            return redact(value) if isinstance(value, str) else value
        row = {"time": datetime.now(timezone.utc).isoformat(), "event": event, **clean(data)}
        with self.path.open("a", encoding="utf-8") as output:
            output.write(json.dumps(row, ensure_ascii=False) + "\n")
        return row


class AuthVault:
    """Windows DPAPI seals storageState for the current Windows user.

    The manager never stores a password. On non-Windows, state stays in memory;
    no plaintext fallback file is created.
    """
    def __init__(self, path: Path):
        self.path = path

    @staticmethod
    def _crypt(raw: bytes, decrypt: bool = False) -> bytes:
        from ctypes import wintypes
        class Blob(ctypes.Structure):
            _fields_ = [("size", wintypes.DWORD), ("data", ctypes.POINTER(ctypes.c_ubyte))]
        data = ctypes.create_string_buffer(raw)
        source = Blob(len(raw), ctypes.cast(data, ctypes.POINTER(ctypes.c_ubyte)))
        dest = Blob()
        fn = ctypes.windll.crypt32.CryptUnprotectData if decrypt else ctypes.windll.crypt32.CryptProtectData
        second = ctypes.POINTER(wintypes.LPWSTR) if decrypt else wintypes.LPCWSTR
        fn.argtypes = [ctypes.POINTER(Blob), second, ctypes.POINTER(Blob),
                       ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
        fn.restype = wintypes.BOOL
        free = ctypes.windll.kernel32.LocalFree
        free.argtypes = [ctypes.c_void_p]
        free.restype = ctypes.c_void_p
        if decrypt:
            ok = fn(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(dest))
        else:
            ok = fn(ctypes.byref(source), "SnayManagerV2", None, None, None, 1, ctypes.byref(dest))
        if not ok:
            raise OSError("Windows認証状態の暗号化・復号に失敗しました")
        try:
            return ctypes.string_at(dest.data, dest.size)
        finally:
            free(dest.data)

    def save(self, state: dict) -> bool:
        if os.name != "nt":
            return False
        raw = self._crypt(json.dumps(state).encode())
        fd, name = tempfile.mkstemp(dir=self.path.parent, prefix="auth-")
        try:
            with os.fdopen(fd, "wb") as output:
                output.write(raw)
            os.replace(name, self.path)
        finally:
            Path(name).unlink(missing_ok=True)
        return True

    def load(self) -> dict | None:
        if os.name != "nt" or not self.path.exists():
            return None
        return json.loads(self._crypt(self.path.read_bytes(), decrypt=True))


def snay_storage_only(state: dict) -> dict:
    """Do not persist identity-provider, advertisement, or unrelated origins."""
    return {
        "cookies": [c for c in state.get("cookies", [])
                    if c.get("domain", "").lstrip(".") in {"snay.io", "www.snay.io"}],
        "origins": [o for o in state.get("origins", [])
                    if o.get("origin") in {"https://snay.io", "https://www.snay.io"}],
    }
