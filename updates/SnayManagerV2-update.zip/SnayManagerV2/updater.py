"""SnayManager V2 source distribution updater.

Apply a trusted SnayManagerV2 ZIP to the existing installation without
requiring the user to unzip it. Personal data lives outside the installation.
"""
from __future__ import annotations

import argparse
import ctypes
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path, PurePosixPath

REQUIRED = {"main.py", "snaymanager/gui.py", "snaymanager/engine.py", "updater.py", "update-manifest.json"}
PRESERVE_TOP = {
    ".venv", "dist", "build", "logs", "data", "userdata", "browser_profiles", "profiles",
    "settings.json", "proxies.json", "auth.json", "storage_state.json", "update.log",
}
SKIP_PARTS = {"__pycache__", ".pytest_cache", ".git", ".idea", ".vscode"}
MAX_FILE = 100 * 1024 * 1024
MAX_TOTAL = 300 * 1024 * 1024


class UpdateError(Exception):
    pass


def _inner_name(value: str) -> Path | None:
    """Return safe path inside the SnayManagerV2 distribution."""
    if "\\" in value or "\x00" in value or value.startswith(("/", "~")):
        raise UpdateError("不正なZIP内ファイル名です")
    parts = PurePosixPath(value).parts
    if any(part in ("..", ".") or ":" in part for part in parts):
        raise UpdateError("ZIPに安全ではないパスが含まれています")
    if parts and parts[0] == "SnayManagerV2":
        parts = parts[1:]
    if not parts:
        return None
    if parts[0].lower() in PRESERVE_TOP or any(p in SKIP_PARTS for p in parts):
        return None
    return Path(*parts)


def inspect_zip(path: Path) -> list[tuple[zipfile.ZipInfo, Path]]:
    if not path.is_file() or not zipfile.is_zipfile(path):
        raise UpdateError("更新ZIPを読み取れません")
    result = []
    seen = set()
    total = 0
    with zipfile.ZipFile(path) as archive:
        for info in archive.infolist():
            dest = _inner_name(info.filename)
            if dest is None or info.is_dir():
                continue
            # Unix symlink encoded inside a ZIP is not acceptable.
            if (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise UpdateError("リンクを含むZIPには対応していません")
            if info.file_size > MAX_FILE:
                raise UpdateError("更新ZIPに大きすぎるファイルがあります")
            total += info.file_size
            if total > MAX_TOTAL:
                raise UpdateError("更新ZIPの展開後容量が上限を超えています")
            normalized = str(dest).replace("\\", "/").casefold()
            if normalized in seen:
                raise UpdateError("更新ZIP内に重複したファイル名があります")
            seen.add(normalized)
            result.append((info, dest))
    missing = REQUIRED - {str(path).replace("\\", "/") for _, path in result}
    if missing:
        raise UpdateError("アップデート対応のSnayManager ZIPではありません（旧版ZIPは利用できません）")
    # A fixed package identity prevents choosing an unrelated project archive.
    import json
    with zipfile.ZipFile(path) as archive:
        manifest = next((info for info, rel in result if rel == Path("update-manifest.json")), None)
        if manifest is None:
            raise UpdateError("更新情報がありません")
        try:
            info = json.loads(archive.read(manifest))
        except (ValueError, UnicodeError) as exc:
            raise UpdateError("更新情報を読み取れません") from exc
        if info.get("package") != "SnayManagerV2" or not isinstance(info.get("version"), str):
            raise UpdateError("SnayManagerの更新ZIPではありません")
    return result


def apply_zip(archive_path: Path, installation: Path) -> int:
    installation = installation.resolve()
    archive_path = archive_path.resolve()
    if not (installation / "main.py").is_file():
        raise UpdateError("更新先にmain.pyがありません。展開したSnayManagerV2フォルダを指定してください")
    files = inspect_zip(archive_path)
    # All staging and rollback data remain on the same disk as the installation.
    with tempfile.TemporaryDirectory(prefix="_snay_update_", dir=installation) as temp:
        work = Path(temp)
        staging, backup = work / "new", work / "old"
        stage_files = []
        with zipfile.ZipFile(archive_path) as archive:
            for info, relative in files:
                candidate = staging / relative
                candidate.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(info) as source, candidate.open("wb") as target:
                    shutil.copyfileobj(source, target)
                stage_files.append(relative)
        changed: list[tuple[Path, bool]] = []
        try:
            for relative in stage_files:
                target = installation / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                had_original = target.is_file()
                if had_original:
                    old = backup / relative
                    old.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(target, old)
                # Add to rollback log before replacing the original.
                changed.append((relative, had_original))
                os.replace(staging / relative, target)
        except Exception as exc:
            for relative, had_original in reversed(changed):
                target = installation / relative
                try:
                    if had_original:
                        os.replace(backup / relative, target)
                    else:
                        target.unlink(missing_ok=True)
                except OSError:
                    pass
            raise UpdateError("更新に失敗したため元のファイルに戻しました: " + str(exc)) from exc
    return len(files)


def wait_for_parent(pid: int, timeout: int = 50) -> None:
    if not pid or pid == os.getpid():
        return
    if os.name == "nt":
        SYNCHRONIZE = 0x00100000
        WAIT_TIMEOUT = 0x102
        kernel32 = ctypes.windll.kernel32
        kernel32.OpenProcess.restype = ctypes.c_void_p
        handle = kernel32.OpenProcess(SYNCHRONIZE, False, pid)
        if handle:
            try:
                if kernel32.WaitForSingleObject(handle, timeout * 1000) == WAIT_TIMEOUT:
                    raise UpdateError("SnayManagerが終了しません。STOP ALLで終了してください")
            finally:
                kernel32.CloseHandle(handle)
    else:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                return
            time.sleep(.2)
        raise UpdateError("SnayManagerの終了を確認できませんでした")


def relaunch(directory: Path) -> None:
    if os.name == "nt":
        script = directory / "RUN_CHECK.cmd"
        if not script.is_file():
            script = directory / "RUN_SOURCE.cmd"
        subprocess.Popen(["cmd.exe", "/c", str(script)], cwd=str(directory),
                         creationflags=subprocess.CREATE_NEW_CONSOLE)
    else:
        subprocess.Popen([sys.executable, str(directory / "main.py")], cwd=str(directory),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def main() -> int:
    parser = argparse.ArgumentParser(description="SnayManager V2 - source ZIP updater")
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--target", type=Path, required=True)
    parser.add_argument("--wait-pid", type=int, default=0)
    parser.add_argument("--restart", action="store_true")
    options = parser.parse_args()
    print("SnayManagerの終了を確認しています...", flush=True)
    try:
        wait_for_parent(options.wait_pid)
        amount = apply_zip(options.archive, options.target)
        print(f"更新完了：{amount}ファイルを適用しました。", flush=True)
        print("ログイン情報・個人設定・仮想環境は保持されています。", flush=True)
        if options.restart:
            relaunch(options.target)
        return 0
    except (UpdateError, OSError, zipfile.BadZipFile) as exc:
        print("[UPDATE ERROR] " + str(exc), file=sys.stderr, flush=True)
        if os.name == "nt":
            try:
                input("Enterキーで閉じます。")
            except EOFError:
                pass
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
